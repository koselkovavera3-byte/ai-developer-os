# AI Developer OS — Bootstrap v0.1

Minimal deterministic vertical slice proving the core loop:

`TASK → PLAN → TOOL → TEST → RUN → VERIFY → TRACE → MEMORY → VERIFIED`

## Run

```bash
python run_smoke.py
```

The bootstrap intentionally uses a deterministic local tool and does not require an external LLM or API key.
