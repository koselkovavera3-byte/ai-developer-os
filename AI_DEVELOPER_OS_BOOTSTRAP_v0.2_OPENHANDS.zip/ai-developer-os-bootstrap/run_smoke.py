import sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent / "src"))
from ai_developer_os.core import Orchestrator, Task, create_project

root=Path(tempfile.mkdtemp(prefix="developer-os-"))
o=Orchestrator(root)
o.tools.register("create_project", create_project)
t=o.run(Task("BOOT-01", "Create a simple project and prove it works at runtime."))
print(f"STATUS={t.status}")
print(f"EVIDENCE={t.evidence[0]}")
print(f"TRACE={root/'trace.json'}")
