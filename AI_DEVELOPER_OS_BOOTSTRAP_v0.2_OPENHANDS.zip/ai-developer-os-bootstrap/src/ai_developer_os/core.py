from dataclasses import dataclass, field
from pathlib import Path
import json, subprocess, sys

@dataclass
class Task:
    id: str
    description: str
    status: str = "PROPOSED"
    evidence: list[str] = field(default_factory=list)

class ToolRegistry:
    def __init__(self): self.tools = {}
    def register(self, name, fn): self.tools[name] = fn
    def run(self, name, *args): return self.tools[name](*args)

class Trace:
    def __init__(self): self.events=[]
    def add(self, event, **data): self.events.append({"event":event, **data})
    def save(self, path): Path(path).write_text(json.dumps(self.events, indent=2), encoding="utf-8")

class Orchestrator:
    def __init__(self, root):
        self.root=Path(root); self.tools=ToolRegistry(); self.trace=Trace()
    def run(self, task: Task):
        task.status="PLANNED"; self.trace.add("plan", task=task.description)
        task.status="RUNNING"; self.trace.add("run")
        self.tools.run("create_project", self.root)
        self.trace.add("tool", name="create_project")
        result=subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=self.root, text=True, capture_output=True)
        self.trace.add("test", returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
        if result.returncode:
            task.status="FAILED"; raise RuntimeError(result.stdout + result.stderr)
        task.status="VERIFYING"
        marker=self.root/"app"/"verified.txt"
        if marker.read_text().strip() != "AI DEVELOPER OS VERIFIED":
            task.status="FAILED"; raise RuntimeError("runtime verification failed")
        task.evidence.append(str(marker)); task.status="VERIFIED"
        self.trace.add("verification", status="VERIFIED", evidence=str(marker))
        self.trace.save(self.root/"trace.json")
        (self.root/"memory.json").write_text(json.dumps({"lesson":"Runtime evidence is required before VERIFIED."}, indent=2), encoding="utf-8")
        return task

def create_project(root):
    root=Path(root); (root/"app").mkdir(parents=True, exist_ok=True); (root/"tests").mkdir(parents=True, exist_ok=True)
    (root/"app"/"verified.txt").write_text("AI DEVELOPER OS VERIFIED", encoding="utf-8")
    (root/"tests"/"test_runtime.py").write_text('from pathlib import Path\ndef test_runtime_marker():\n    assert (Path("app") / "verified.txt").read_text().strip() == "AI DEVELOPER OS VERIFIED"\n', encoding="utf-8")
