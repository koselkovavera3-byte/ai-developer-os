from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os


@dataclass
class OpenHandsConfig:
    model: str | None = None
    api_key: str | None = None
    workspace: str = "."


class OpenHandsUnavailable(RuntimeError):
    pass


class OpenHandsDeveloper:
    """Thin boundary: our OS owns orchestration; OpenHands only executes coding work."""

    def __init__(self, config: OpenHandsConfig):
        self.config = config

    def available(self) -> bool:
        try:
            import openhands.sdk  # type: ignore
            return True
        except ImportError:
            return False

    def execute(self, task: str) -> str:
        if not self.available():
            raise OpenHandsUnavailable(
                "OpenHands SDK is not installed. Install matching openhands-sdk and "
                "openhands-tools releases before enabling live execution."
            )
        if not self.config.api_key and not os.getenv("LLM_API_KEY"):
            raise OpenHandsUnavailable("LLM_API_KEY is required for live OpenHands execution.")

        from openhands.sdk import Agent, Conversation, LLM, Tool  # type: ignore
        from openhands.tools.file_editor import FileEditorTool  # type: ignore
        from openhands.tools.terminal import TerminalTool  # type: ignore

        llm = LLM(
            model=self.config.model or os.getenv("LLM_MODEL", ""),
            api_key=self.config.api_key or os.getenv("LLM_API_KEY"),
        )
        agent = Agent(
            llm=llm,
            tools=[Tool(name=TerminalTool.name), Tool(name=FileEditorTool.name)],
        )
        conversation = Conversation(agent=agent, workspace=Path(self.config.workspace).resolve())
        conversation.send_message(task)
        conversation.run()
        return "OPENHANDS_EXECUTION_COMPLETED"
