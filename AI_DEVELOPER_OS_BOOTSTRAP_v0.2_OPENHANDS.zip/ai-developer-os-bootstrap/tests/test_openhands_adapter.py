import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1] / "src"))

from ai_developer_os.openhands_adapter import OpenHandsDeveloper, OpenHandsConfig, OpenHandsUnavailable


def test_adapter_isolated_when_sdk_is_absent():
    agent = OpenHandsDeveloper(OpenHandsConfig(workspace="."))
    if agent.available():
        return
    try:
        agent.execute("Create a minimal test file and verify it.")
    except OpenHandsUnavailable as exc:
        assert "OpenHands SDK is not installed" in str(exc)
    else:
        raise AssertionError("Expected explicit unavailable state")
